Advanced Topics
===============

The following documentation is available for additional topics for users looking to learn more about ElastAlert 2.

.. toctree::
   :maxdepth: 1

   recipes/writing_filters
   extending
   elastalert_status
   elasticsearch_security_privileges
   recipes/exposing_rule_metrics
   recipes/signing_requests