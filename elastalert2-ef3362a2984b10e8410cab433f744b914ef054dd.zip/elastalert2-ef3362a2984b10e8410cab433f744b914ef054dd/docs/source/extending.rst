Extending ElastAlert 2
======================

ElastAlert 2 offers a variety of ways to extend the functionality. This includes adding your own rules, your own alerts, rule loaders, etc.

.. toctree::
   :maxdepth: 1

   recipes/adding_rules
   recipes/adding_alerts
   recipes/adding_enhancements
   recipes/adding_loaders
