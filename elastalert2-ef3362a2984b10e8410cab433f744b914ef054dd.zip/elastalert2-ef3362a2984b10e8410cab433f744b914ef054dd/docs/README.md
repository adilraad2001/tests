# Documentation

You can read this documentation at [Read The Docs][0].

To build a local version of these docs, the following from within the `/docs` directory:

```
pip install sphinx_rtd_theme sphinx
make html
```

You can then view the generated HTML in from within the `build/` folder.
